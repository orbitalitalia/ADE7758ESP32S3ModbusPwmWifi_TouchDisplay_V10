#ifndef WEBSERVER_H
#define WEBSERVER_H


#include <WebServer.h>
#include <WebSocketsServer.h>  // Adăugăm WebSockets

extern WebSocketsServer webSocket;
void onWebSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length);
void startWebServer();
void handleWebClient();
//void broadcastMeasurements();  // Nouă funcție pentru broadcast

#endif

#include <WiFi.h>
#include <WebServer.h>
//#include <ETH.h>
#include "globals.h"

// Declarăm funcțiile
void initWebServerAndSocket();

void startWebServer();
void loopWebSocket();  // apelabil din .ino
void handleWebClient();
void handleRoot();
void handleData();
void handleSetEnergy();
void handleCalibrate();
void handleNotFound();

void handleToggleManualControl();
void handleToggleStep2();
void handleToggleStep3();
void handleToggleStep4();

// Declarăm funcțiile
bool isGPIO0Safe();
bool safeGPIOInit();


void handleToggleStep();
void handleSetStepF();

extern bool resetEnergyRequested;
