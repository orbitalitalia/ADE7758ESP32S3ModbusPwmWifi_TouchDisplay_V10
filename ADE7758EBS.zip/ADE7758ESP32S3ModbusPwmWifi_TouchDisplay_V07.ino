// V7.0 ADE7758 with ESP32 S3 Devmodule - VERSIUNEA CORECTATĂ MODBUS + WiFi + OTA Independent functioneaza perfect !!
// Model functional calibrat pe faza A,B si C
// OLED on pins GPIO48(SDA) and GPIO47 (SCL), +3.3V
// conectare web WiFi la 192.168.1.177 (WiFi AP întotdeauna pornit)
// ethernet webpage 192.168.1.20 (când cablul este conectat)
// touch pin 4
// OTA admin orbital123
//


#include "globals.h"
#include <dummy.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Wire.h>
#include <SPI.h>
#include "ADE7758.h"
#include "ETHClass.h"
#include <WiFiClient.h>
#include <esp_sleep.h>
#include "WebServer.h"
#include "esp32-hal-cpu.h"
#include "NVRAM.h"
#include <Adafruit_MCP4725.h>
#include "esp_ota_ops.h"

static bool fwConfirmed = false;

// Profiler simplu de test... stergem dupa !
struct Prof {
  uint32_t lastPrintMs = 0;
  uint32_t maxWebUs = 0;
  uint32_t maxMeterUs = 0;
} prof;

static inline void profUpdate(uint32_t &m, uint32_t dt){
  if (dt > m) m = dt;
}

// end profiler

static const char* otaStateName(esp_ota_img_states_t s){
  switch(s){
    case ESP_OTA_IMG_NEW:            return "NEW";
    case ESP_OTA_IMG_PENDING_VERIFY: return "PENDING_VERIFY";
    case ESP_OTA_IMG_VALID:          return "VALID";
    case ESP_OTA_IMG_INVALID:        return "INVALID";
    case ESP_OTA_IMG_ABORTED:        return "ABORTED";
    case ESP_OTA_IMG_UNDEFINED:      return "UNDEFINED";
    default:                         return "?";
  }
}

void printOtaState() {
  const esp_partition_t* run = esp_ota_get_running_partition();
  esp_ota_img_states_t st = ESP_OTA_IMG_UNDEFINED;
  esp_err_t e = esp_ota_get_state_partition(run, &st);
  Serial.printf("RUN partition: %s, state=%s, err=%s\n",
                run ? run->label : "NULL",
                otaStateName(st),
                esp_err_to_name(e));
}

// Function declarations
void modbusTickKAandWatt();     // îl chemăm în loop (but we'll disable calling it)
static bool modbusWrite16(uint16_t reg, uint16_t value);
static bool modbusReadInput16(uint16_t reg, uint16_t &outValue);
static void modbusKeepAlive();
static inline uint16_t clamp16(uint32_t x) { return x > 0xFFFF ? 0xFFFF : (uint16_t)x; }
void factoryResetCalibration();


// Loop monitoring
static uint32_t g_lastLoopTime = 0;
static uint32_t g_loopCounter = 0;

// ✅ VARIABILELE SUNT EXTERNE - DEFINITE ÎN globals.cpp
extern ETHClass ETH;
extern WiFiClient client;  // 👈 Use global client from globals.cpp
Adafruit_SSD1306 display = Adafruit_SSD1306(128, 64, &Wire);
Adafruit_MCP4725 dac;

// SPI pentru W5500 pe ESP32-S3
#define SPI_FREQ 250000
#define W5500_MISO 12
#define W5500_MOSI 11
#define W5500_SCLK 13
#define W5500_CS 14
#define W5500_RST 9
#define W5500_IRQ 10

#undef  MODBUS_UNIT_ID
#define MODBUS_UNIT_ID 1

// Network settings
byte mac[] = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED };
IPAddress ip(192, 168, 1, 20);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);

// Flags pentru starea conexiunilor
bool wifiAPStarted = false;
bool lastEthernetState = true;
bool lastModbusState = true;
static bool eth_initialized = false;

unsigned long lastModbusRetry = 0;

// ---------------- Modbus config (WRITE-ONLY) ----------------

// Input register (FC04) pentru "Potenza rete" (server Modbus): input 13
// NOTE: se aplică MODBUS_ONE_BASED la calculul adresei (ca la scriere).
static const uint16_t MODBUS_INPUT_POTENZA_RETE = 13;

static const unsigned long MODBUS_REPLY_TIMEOUT_MS = 1000; // ms

// Timers
const int MODBUS_WATT_PERIOD = 500;   // ms, scriere Watt
const int MODBUS_KA_PERIOD = 1000;    // ms, keep-alive

// Variabile pentru comunicația Modbus
int stay_alive = 0;
unsigned long lastStayAliveUpdate = 0;
const unsigned long MODBUS_UPDATE_INTERVAL = 1000; // 1s
unsigned long lastModbusUpdate = 0;

// Pin definitions
const int analogPin = 39;            // GPIO39 (ADC1_3) tensiune alimentare
const int analogPinBat = 38;         // GPIO38 tensiune baterie
const int IRQ_PIN = 3;               // GPIO3 pentru IRQ
const float voltageThreshold = 3.2;  // Voltage threshold for power loss

// ==================== TOUCH DISPLAY CONTROL ====================
#define TOUCH_PIN 4                         // GPIO4 (TOUCH4) for touch input - ESP32-S3 valid touch pin!
#define TOUCH_THRESHOLD_HIGH 20000          // High threshold for touch detection
#define TOUCH_THRESHOLD_LOW 15000           // Low threshold for touch release
                                            // Hysteresis: Touch when value > HIGH, Release when value < LOW
                                            // Resting value ~19000, touched ~43000+
#define DISPLAY_TIMEOUT 60000              // 1 minutes in milliseconds
volatile bool displayOn = true;             // Display state flag
volatile unsigned long lastTouchTime = 0;   // Last touch timestamp
// ===============================================================

// Global measurement variables
double v = 0, v_a = 0, v_b = 0, v_c = 0;  // Voltages
double c = 0, c_a = 0, c_b = 0, c_c = 0;  // Currents
extern float Watt;                        // Total Active Power - EXTERN
float Pf = 0;                             // Total Power Factor
double Frequency;                         // Line frequency
float batteryVoltage = 0.0;               // Battery Voltage
const int numReadings = 10;
float TensAlimentare = 0.0;         // tensiune alimentare
bool resetEnergyRequested = false;  // Flag for energy reset

static inline int32_t signExtend24(uint32_t x) {
  x &= 0xFFFFFF;
  if (x & 0x800000) x |= 0xFF000000;
  return (int32_t)x;
}

static inline int32_t deltaSigned24(uint32_t now24, uint32_t prev24) {
  uint32_t d = (now24 - prev24) & 0xFFFFFF;   // delta modulo 24-bit
  return signExtend24(d);
}

static uint32_t prevWhr24[3]  = {0,0,0};
static uint32_t prevVahr24[3] = {0,0,0};
static bool pfInit = false;

// filtrare ușoară ca să nu sară PF-ul
static float pfFilt[3] = {1.0f,1.0f,1.0f};



// Variabile rezistente - EXTERNE
extern bool Step2;
extern bool Step3;
extern bool Step4;

#define DIV 2

#define WATT_CAL 0.03961
#define Var_CAL 0.03965
#define VA_CAL 0.03965
#define VRMS_CAL 15
#define IRMS_CAL 15

// setting PWM properties
const int PWM_PIN = 21;     // GPIO-ul 21 folosit pentru PWM -pin 23
const int PWM_CHANNEL = 0;  // Canal PWM
const int PWM_FREQ = 3000;  // Frecvența PWM
const int PWM_RES = 12;     // Rezoluția PWM (12 biți)

int pwm;
extern int Step1;                     // Valoarea Step1 bazată pe PWM (0 - 100) - EXTERN
float PowerRez = 750.0;               // Putere rezistente in kW
int numSteps = 4;                     // Număr de step-uri (1, 2, 3 sau 4)
float Prez1 = 300;                    // Valoarea pentru Step1 (% din PowerRez)
float Prez2 = 125;                    // Valoarea pentru Step2 (% din PowerRez)
float Prez3 = 250;                    // Valoarea pentru Step3 (% din PowerRez)
float Prez4 = 250;                    // Valoarea pentru Step4 (% din PowerRez)
int current_step = 1;                 // Urmărește step-ul activ
float current_threshold = Prez1;      // Pragul curent de activare
bool reset_pwm = true;                // Indicator pentru resetarea PWM1
float pwm_accumulated = 0;            // Variabilă pentru acumularea PWM1

extern void sendLiveData();

// Task handle pentru Core 2
TaskHandle_t TaskHandle_Core2;

float Watt_a, WattA, Watt_b, WattB, Watt_c, WattC, kWh;
float Var_a, Var_b, Var_c, Var;
float VA, VA_a, VA_b, VA_c;
float Pfa, PfA, PfB, PfC;  // 👈 POWER FACTOR — RESTORED
float voltageFactor = 1;
float currentFactor = 1;


float totalEnergy = 0.0;
extern int setpoint;  // valoarea inițială de 300W - EXTERN
float KWh = 0.0;     // Energia acumulată
unsigned long previousMillis = 0;

void factoryResetCalibration() {
  factoryCalDone = false;

  // șterge offseturile (în counts) din FRAM
  nvramWriteFloat(ADDR_VOLTAGE_OFFSET_A, 0.0f);
  nvramWriteFloat(ADDR_VOLTAGE_OFFSET_B, 0.0f);
  nvramWriteFloat(ADDR_VOLTAGE_OFFSET_C, 0.0f);

  nvramWriteFloat(ADDR_CURRENT_OFFSET_A, 0.0f);
  nvramWriteFloat(ADDR_CURRENT_OFFSET_B, 0.0f);
  nvramWriteFloat(ADDR_CURRENT_OFFSET_C, 0.0f);

  // salvează flag-ul
  nvramWriteInt(ADDR_FACTORY_CAL_DONE, 0);

  DBG_PRINTLN("✅ Factory calibration cleared (offsets=0, factoryCalDone=FALSE).");
}


// =================== MODBUS WRITE (FC06) ===================
static bool modbusWrite16(uint16_t reg, uint16_t value) {
  if (!ETH.linkUp() || ETH.localIP() == IPAddress(0,0,0,0)) return false;
  if (!client.connected()) return false;

  if (g_modbusMutex && xSemaphoreTake(g_modbusMutex, pdMS_TO_TICKS(100)) != pdTRUE) {
    return false;
  }

  const uint16_t addr0 = MODBUS_ONE_BASED ? (reg - 1) : reg;
  const uint16_t tid   = g_modbusTid++;

  uint8_t req[12] = {
    (uint8_t)(tid>>8),(uint8_t)tid, 0,0, 0,6,
    MODBUS_UNIT_ID, 0x06,
    (uint8_t)(addr0>>8),(uint8_t)(addr0&0xFF),
    (uint8_t)(value>>8),(uint8_t)(value&0xFF)
  };

  client.setTimeout(1000); // ⚠️ CRITICAL — prevent hangs

  int wrote = client.write(req, sizeof(req));
  bool success = (wrote == (int)sizeof(req));

  unsigned long startDrain = millis();
  while (client.available() > 0 && (millis() - startDrain < 500)) {
    client.read();
  }

  if (g_modbusMutex) xSemaphoreGive(g_modbusMutex);

  if (!success) {
    DBG_PRINTLN("⚠️ Modbus write failed");
    client.stop();
  }

  return success;
}

// =================== MODBUS READ INPUT (FC04) ===================
// Citește 1 x Input Register (16-bit) de la adresa "reg".
static bool modbusReadInput16(uint16_t reg, uint16_t &outValue) {
  if (!ETH.linkUp() || ETH.localIP() == IPAddress(0, 0, 0, 0)) return false;
  if (!client.connected()) return false;

  if (g_modbusMutex && xSemaphoreTake(g_modbusMutex, pdMS_TO_TICKS(150)) != pdTRUE) {
    return false;
  }

  const uint16_t addr0 = MODBUS_ONE_BASED ? (reg - 1) : reg;
  const uint16_t tid   = g_modbusTid++;

  // MBAP(7) + PDU(5) = 12 bytes
  uint8_t req[12] = {
    (uint8_t)(tid >> 8), (uint8_t)tid, 0, 0, 0, 6,
    MODBUS_UNIT_ID, 0x04,
    (uint8_t)(addr0 >> 8), (uint8_t)(addr0 & 0xFF),
    0x00, 0x01
  };

  client.setTimeout(MODBUS_REPLY_TIMEOUT_MS);
  int wrote = client.write(req, sizeof(req));
  if (wrote != (int)sizeof(req)) {
    if (g_modbusMutex) xSemaphoreGive(g_modbusMutex);
    return false;
  }

  // Citim MBAP (7 bytes) ca să aflăm lungimea reală a răspunsului.
  uint8_t mbap[7];
  int got = client.readBytes(mbap, sizeof(mbap));
  if (got != (int)sizeof(mbap)) {
    if (g_modbusMutex) xSemaphoreGive(g_modbusMutex);
    return false;
  }

  const uint16_t len = ((uint16_t)mbap[4] << 8) | mbap[5]; // include UnitID
  if (len < 3 || len > 64) { // sanity
    if (g_modbusMutex) xSemaphoreGive(g_modbusMutex);
    return false;
  }

  const uint16_t remaining = (len >= 1) ? (len - 1) : 0; // fără UnitID (deja citit în MBAP)
  uint8_t pdu[64];
  if (remaining > sizeof(pdu)) {
    if (g_modbusMutex) xSemaphoreGive(g_modbusMutex);
    return false;
  }
  got = client.readBytes(pdu, remaining);

  // Drain eventual bytes rămase, fără să blocăm.
  unsigned long startDrain = millis();
  while (client.available() > 0 && (millis() - startDrain < 200)) {
    client.read();
  }

  if (g_modbusMutex) xSemaphoreGive(g_modbusMutex);

  if (got != (int)remaining) return false;
  if (mbap[6] != MODBUS_UNIT_ID) return false;

  // PDU: FC, ByteCount, Data...
  if (remaining < 4) return false;
  if (pdu[0] != 0x04) return false;
  if (pdu[1] != 0x02) return false;

  outValue = ((uint16_t)pdu[2] << 8) | pdu[3];
  return true;
}

// =================== CONTROL PWM & LOGIC - PWM RESCALAT PE PREZ1 ===================
void updatePWMFromWatt(void *pvParameters) {
  struct StageCfg {
    bool* stepFlag;
    int   threshold;
  };

  while (1) {
    if (!manualControlEnabled) {
      volatile float wattA_local = WattA;
      volatile float wattB_local = WattB;
      volatile float wattC_local = WattC;
      float wattIn = wattA_local + wattB_local + wattC_local;
      float wattVal = wattIn;

      float diff = (wattVal * 1000.0f) - setpoint;

      // Resetăm stările
      Step2 = Step3 = Step4 = false;
      pwm1  = 0;

      if (diff > 0) {
        float prezAnalog = (prez1 > 0) ? (float)prez1 : 1.0f;
        float remaining  = diff;

        // ========== ZONA 1: doar PWM (0 → prez1) ==========
        if (remaining <= prezAnalog) {
          // PWM: 0→100% = 0→prez1
          pwm1 = map((long)remaining, 0L, (long)prezAnalog, 0L, 4095L);
        } 
        else {
          // Am depășit zona 1
          remaining -= prezAnalog;

          // ✅ FIX BUG: Activare EXPLICITĂ a treptelor la praguri cumulative
          // Astfel TOATE treptele anterioare sunt activate corect!
          
          float threshold_step2 = 0;
          float threshold_step3 = 0;
          float threshold_step4 = 0;
          
          if (prez2 > 0) {
            threshold_step2 = (float)prez2;
            threshold_step3 = threshold_step2 + ((prez3 > 0) ? (float)prez3 : 0.0f);
            threshold_step4 = threshold_step3 + ((prez4 > 0) ? (float)prez4 : 0.0f);
          }

          // Activăm trepte în funcție de remaining
          if (remaining > 0 && prez2 > 0) {
            Step2 = true;
          }
          if (remaining > threshold_step2 && prez3 > 0) {
            Step3 = true;
          }
          if (remaining > threshold_step3 && prez4 > 0) {
            Step4 = true;
          }

          // Calculăm PWM rescalat pe prez1
          if (prez2 > 0 && remaining <= threshold_step2) {
            // Zonă Step2
            pwm1 = map((long)remaining, 0L, (long)prezAnalog, 0L, 4095L);
          }
          else if (prez3 > 0 && remaining <= threshold_step3) {
            // Zonă Step3
            float rem_in_zone = remaining - threshold_step2;
            pwm1 = map((long)rem_in_zone, 0L, (long)prezAnalog, 0L, 4095L);
          }
          else if (prez4 > 0 && remaining <= threshold_step4) {
            // Zonă Step4
            float rem_in_zone = remaining - threshold_step3;
            pwm1 = map((long)rem_in_zone, 0L, (long)prezAnalog, 0L, 4095L);
          }
          else {
            // Depășit toate zonele
            pwm1 = 4095;  // Saturație
          }
        }
      }

      pwm1 = constrain(pwm1, 0, 4095);
      Step1 = pwm1;
    }

    // Aplică PWM + DAC
    ledcWrite(0, pwm1);
    dac.setVoltage((uint16_t)pwm1, false);

    // Trepte digitale
    digitalWrite(STEP2_PIN, Step2 ? HIGH : LOW);
    digitalWrite(STEP3_PIN, Step3 ? HIGH : LOW);
    digitalWrite(STEP4_PIN, Step4 ? HIGH : LOW);

    vTaskDelay(100 / portTICK_PERIOD_MS);
  }
}


void setPWM(int val) {
  // Inversează valoarea: 0 → 4095, 4095 → 0
  int invertedVal = 4095 - val;
  
  ledcWrite(PWM_CHANNEL, invertedVal);

}

// =================== WiFi/Ethernet Events ===================
void WiFiEvent(WiFiEvent_t event) {
  switch (event) {
    case ARDUINO_EVENT_ETH_START:
      DBG_PRINTLN("Ethernet started");
      ETH.setHostname("ESP32-Modbus");
      break;
    case ARDUINO_EVENT_ETH_CONNECTED:
      DBG_PRINTLN("Ethernet connected");
      DBG_PRINT("IP Address: ");
      DBG_PRINTLN(ETH.localIP());
      break;
    case ARDUINO_EVENT_ETH_DISCONNECTED:
      DBG_PRINTLN("Ethernet disconnected");
      break;
    case ARDUINO_EVENT_ETH_GOT_IP:
      DBG_PRINT("Ethernet IP: ");
      DBG_PRINTLN(ETH.localIP());
      break;
    default:
      break;
  }
}

// ✅ VERSIONE CORRETTA di safeGPIOInit()
// Sostituisci la funzione esistente nel main.ino (linea ~272) con questa:

bool safeGPIOInit() {
  DBG_PRINTLN("Starting safe GPIO initialization...");

  // ✅ PRIMA: Reset esplicito variabili a ZERO
  Step1 = 0;
  Step2 = false;
  Step3 = false;
  Step4 = false;
  pwm1 = 0;
  
  DBG_PRINTLN("Setting pins as INPUT_PULLUP...");
  pinMode(STEP2_PIN, INPUT_PULLUP);
  pinMode(STEP3_PIN, INPUT_PULLUP);
  pinMode(STEP4_PIN, INPUT_PULLUP);
  delay(10);

  DBG_PRINTLN("System stabilized, attempting to configure outputs...");

  bool success = true;
  
  // ✅ FORZA tutti i pin a LOW (zero), non leggere variabili
  DBG_PRINTLN("Configuring STEP2...");
  pinMode(STEP2_PIN, OUTPUT);
  digitalWrite(STEP2_PIN, LOW);  // ✅ Forza LOW (non Step2 ? HIGH : LOW)
  delay(100);

  DBG_PRINTLN("Configuring STEP3...");
  pinMode(STEP3_PIN, OUTPUT);
  digitalWrite(STEP3_PIN, LOW);  // ✅ Forza LOW
  delay(100);

  DBG_PRINTLN("Configuring STEP4...");
  pinMode(STEP4_PIN, OUTPUT);
  digitalWrite(STEP4_PIN, LOW);  // ✅ Forza LOW
  delay(100);

  DBG_PRINTLN("✅ GPIO initialization complete - all outputs set to ZERO");
  return success;
}

void resetW5500() {
  pinMode(W5500_RST, OUTPUT);
  digitalWrite(W5500_RST, LOW);
  delay(500);
  digitalWrite(W5500_RST, HIGH);
  delay(500);
  DBG_PRINTLN("🔄 W5500 reset complet!");
}


// =================== TOUCH HANDLERS ===================
// Touch detection using edge detection in checkTouchTimeout()
// No ISR needed - manual polling with edge detection


void checkTouchTimeout() {
  // Hysteresis - use two thresholds to avoid oscillation
  static bool wasTouched = false;
  uint16_t touchValue = touchRead(TOUCH_PIN);
  bool isTouched;
  
  // Hysteresis logic:
  // - If NOT touched: must go above HIGH threshold to detect touch
  // - If already touched: must go below LOW threshold to release
  if (!wasTouched) {
    isTouched = (touchValue > TOUCH_THRESHOLD_HIGH);  // Need HIGH value to trigger
  } else {
    isTouched = (touchValue > TOUCH_THRESHOLD_LOW);   // Need to drop below LOW to release
  }
  
  // Only reset timeout when transitioning from NOT touched to touched
  if (isTouched && !wasTouched) {
    lastTouchTime = millis();
    if (!displayOn) {
      displayOn = true;
      DBG_PRINTLN("🔆 Display ON - Touch detected");
    } else {
      DBG_PRINTLN("👆 Touch detected - timeout reset");
    }
  }
  
  wasTouched = isTouched;  // Remember state for next iteration
  
  // Check timeout - turn off display after 5 minutes
  if (displayOn && (millis() - lastTouchTime > DISPLAY_TIMEOUT)) {
    displayOn = false;
    DBG_PRINTLN("🌙 Display OFF - 5 minute timeout");
  }
}

void OledTask(void *pvParameters) {
  for (;;) {
    // Check touch timeout
    checkTouchTimeout();
    
    // Track display state for clearing logic
    static bool cleared = false;
    
    if (displayOn) {
      // Display is ON - reset cleared flag
      cleared = false;
      
      // Display is ON
    if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
      display.clearDisplay();

      // --- LIVE MEASUREMENTS (always updated) ---
      display.setTextSize(2);
      display.setCursor(2, 0);
      display.print(Watt);
      display.setCursor(100, 0);
      display.print("kW");

      display.setCursor(2, 16);
      display.print(v_a);
      display.setCursor(100,16);
      display.print("V");

      display.setCursor(2, 32);
      display.print(c_a);
      display.setCursor(100,32);
      display.print("A");

      display.setTextSize(1);
      display.setCursor(2, 48);
      display.print("PWM: ");
      display.setCursor(28, 48);
      display.print(pwm1);
      display.setCursor(68,48);
      display.print("Pf: ");
      display.setCursor(90, 48);
      display.print(PfA);

      display.setCursor(24,57);
      display.print("kWh:  ");
      display.setCursor(49, 57);
      display.print(KWh);

      // --- NETWORK STATUS (only indicator) ---
      display.setCursor(0, 57);
      if (ETH.linkUp() && modbusConnected && !g_netBusy) {
        display.print("MB");   // cable + Modbus OK
      } else if (ETH.linkUp()) {
        display.print("Eth");  // cable OK, Modbus dead
      } else {
        display.print("--");   // no cable
      }

      display.display();
      xSemaphoreGive(i2cMutex);
    }

    } else {
      // Display is OFF - clear it once
      if (!cleared && xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
        display.clearDisplay();
        display.display();
        xSemaphoreGive(i2cMutex);
        cleared = true;
      }
    }
    vTaskDelay(pdMS_TO_TICKS(200)); // refresh la 200ms e suficient
  }
}


// ==================== Task pentru Modbus ====================
void ModbusTask(void *pvParameters) {
  static uint16_t ka = 0;
  static uint32_t lastReconnectAttempt = 0;
  static uint32_t lastReadPwrRete = 0;

  for (;;) {
    if (ethernetConnected && modbusConnected) {
      // ✅ LIVENESS CHECK
      if (!client.connected()) {
        DBG_PRINTLN("⚠️ Modbus TCP dead → reconnecting");
        client.stop();
        modbusConnected = false;
        vTaskDelay(pdMS_TO_TICKS(500));
        continue;
      }

      // --- RETRY WATT ---
      bool wattSuccess = false;
      uint16_t watt_int = clamp16((uint32_t)(Watt * 1000.0f));
      for (int retry = 0; retry < 3; retry++) {
        if (modbusWrite16(MODBUS_REG_WATT, watt_int)) {
          wattSuccess = true;
          g_lastModbusTxMs = millis(); // ✅ Reset idle timer
          break;
        }
        vTaskDelay(pdMS_TO_TICKS(100));
      }
      if (!wattSuccess) {
        DBG_PRINTLN("❌ WATT failed x3 → reconnecting");
        client.stop();
        modbusConnected = false;
        continue;
      }

      // --- RETRY KA ---
      bool kaSuccess = false;
      for (int retry = 0; retry < 3; retry++) {
        if (modbusWrite16(MODBUS_REG_STAY_ALIVE, ka++)) {
          kaSuccess = true;
          g_lastModbusTxMs = millis(); // ✅ Reset idle timer
          break;
        }
        vTaskDelay(pdMS_TO_TICKS(100));
      }
      if (!kaSuccess) {
        DBG_PRINTLN("❌ KA failed x3 → reconnecting");
        client.stop();
        modbusConnected = false;
        continue;
      }

      if (ka > 9999) ka = 1;

      // --- READ Potenza rete (Input 13, FC04) ---
      const uint32_t now = millis();
      if (now - lastReadPwrRete >= 1000) {
        uint16_t raw = 0;
        bool ok = false;
        for (int retry = 0; retry < 2; retry++) {
          if (modbusReadInput16(MODBUS_INPUT_POTENZA_RETE, raw)) {
            ok = true;
            g_lastModbusRxMs = millis();
            break;
          }
          vTaskDelay(pdMS_TO_TICKS(80));
        }
        if (ok) {
          // Presupunere: valoarea e în W (signed). Convertim în kW.
          int16_t s = (int16_t)raw;

          PowerRete = (float)s / 10.0f; // normal e 1000 , dar din registru se citeste x100
        }
        lastReadPwrRete = now;
      }

    } else if (ethernetConnected && !modbusConnected) {
      // --- RECONNECT ---
      if (millis() - lastReconnectAttempt >= 5000 || lastReconnectAttempt == 0) {
        DBG_PRINT("🔗 Attempting Modbus reconnect to ");
        DBG_PRINTLN(MODBUS_SLAVE_IP);

        client.stop();

        uint32_t startAttempt = millis();
        bool connected = false;
        while (millis() - startAttempt < 3000) {
          if (client.connect(MODBUS_SLAVE_IP, MODBUS_PORT)) {
            connected = true;
            break;
          }
          vTaskDelay(pdMS_TO_TICKS(100));
        }

        if (connected) {
          DBG_PRINTLN("🎉 Modbus connected successfully!");
          modbusConnected = true;
          client.setTimeout(2000);
          g_lastModbusTxMs = millis(); // ✅ Reset timer
          lastReconnectAttempt = millis();
        } else {
          DBG_PRINTLN("❌ Modbus reconnect failed (timeout after 3s)");
          lastReconnectAttempt = millis();
        }
      }
    }

    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

// =================== MODBUS TICK (DISABLED IN LOOP, BUT DEFINED) ===================
void modbusTickKAandWatt() {
  static uint32_t lastWattSend = 0;
  static uint32_t lastKASend   = 0;
  const uint32_t now = millis();

  if (!ethernetConnected) {
    modbusConnected = false;
    return;
  }

  if (!modbusConnected) {
    return;
  }

  // =================== Scriere WATT ===================
  if (now - lastWattSend >= 500) {
    uint32_t wattInt = (uint32_t)(Watt * 1000.0f);
    if (wattInt > 0xFFFF) wattInt = 0xFFFF;

    if (!modbusWrite16(MODBUS_REG_WATT, (uint16_t)wattInt)) {
      DBG_PRINTLN("❌ Modbus WATT write failed → closing client");
      client.stop();
      modbusConnected = false;
      return;
    }
    lastWattSend = now;
  }

  // =================== Scriere KEEP-ALIVE ===================
  if (now - lastKASend >= 1000) {
    static uint16_t kaValue = 1;
    if (!modbusWrite16(MODBUS_REG_STAY_ALIVE, kaValue)) {
      DBG_PRINTLN("❌ Modbus KA write failed → closing client");
      client.stop();
      modbusConnected = false;
      return;
    }
    kaValue++;
    if (kaValue > 9999) kaValue = 1;
    lastKASend = now;
  }
}

void calibrazioneAutomaticaOffset() {

    if (factoryCalDone) {
        Serial.println("\n⛔ Factory calibration already done.");
        return;
    }

    Serial.println("\n🔧 CALIBRAZIONE OFFSET");
    Serial.println("⚠️  Scollega TUTTI i carichi (I=0A)!");
    Serial.println("⚠️  Per calibrare tensione, assicurati che l'ingresso sia a 0V!");
    Serial.println("Premi Enter...");
    while (Serial.available() == 0) delay(10);
    while (Serial.available() > 0) Serial.read();

    Serial.println("📊 50 campioni...");

    long sumI_A = 0, sumI_B = 0, sumI_C = 0;
    long sumV_A = 0, sumV_B = 0, sumV_C = 0;

    for (int i = 0; i < 50; i++) {


        sumI_A += meter.getIRMS(PHASE_A);
        sumI_B += meter.getIRMS(PHASE_B);
        sumI_C += meter.getIRMS(PHASE_C);

        sumV_A += meter.getVRMS(PHASE_A);
        sumV_B += meter.getVRMS(PHASE_B);
        sumV_C += meter.getVRMS(PHASE_C);


        Serial.print(".");
        if ((i+1) % 10 == 0) Serial.println();

        delay(50);
    }

    // ⚠️ Împărțire FLOAT corectă (fără pierdere precizie)
    // offsets sunt COUNTS
    currentOffsetA = (float)sumI_A / 50.0f;
    currentOffsetB = (float)sumI_B / 50.0f;
    currentOffsetC = (float)sumI_C / 50.0f;

    voltageOffsetA = (float)sumV_A / 50.0f;
    voltageOffsetB = (float)sumV_B / 50.0f;
    voltageOffsetC = (float)sumV_C / 50.0f;

    // ✅ Scrie offseturile DIRECT in FRAM (fara conditii)
    nvramWriteFloat(ADDR_VOLTAGE_OFFSET_A, voltageOffsetA);
    nvramWriteFloat(ADDR_VOLTAGE_OFFSET_B, voltageOffsetB);
    nvramWriteFloat(ADDR_VOLTAGE_OFFSET_C, voltageOffsetC);

    nvramWriteFloat(ADDR_CURRENT_OFFSET_A, currentOffsetA);
    nvramWriteFloat(ADDR_CURRENT_OFFSET_B, currentOffsetB);
    nvramWriteFloat(ADDR_CURRENT_OFFSET_C, currentOffsetC);

    DBG_PRINTLN("\n🔎 VERIFY FRAM (imediat dupa nvramWriteFloat)");

DBG_PRINTf("Wrote IoffA=%.0f VoffA=%.0f\n", currentOffsetA, voltageOffsetA);

float rI = nvramReadFloat(ADDR_CURRENT_OFFSET_A);
float rV = nvramReadFloat(ADDR_VOLTAGE_OFFSET_A);

DBG_PRINTf("Read  IoffA=%.0f VoffA=%.0f\n", rI, rV);


    // ✅ Abia acum setezi flag-ul si il salvezi
    factoryCalDone = true;
    nvramWriteInt(ADDR_FACTORY_CAL_DONE, 1);

    // Salveaza restul setarilor (offseturile nu vor fi rescrise)
    saveSettingsToNVRAM();

    Serial.println("\n✅ Offset salvati (counts):");
    Serial.printf("I_A: %.0f  I_B: %.0f  I_C: %.0f\n", currentOffsetA, currentOffsetB, currentOffsetC);
    Serial.printf("V_A: %.0f  V_B: %.0f  V_C: %.0f\n", voltageOffsetA, voltageOffsetB, voltageOffsetC);
    Serial.println("💾 Salvato! FactoryCalDone=TRUE\n");

}
void doMeasurements() {

  const uint32_t now_ms = millis();

  static uint32_t lastMeasurement = 0;
  if (now_ms - lastMeasurement < MEASUREMENT_INTERVAL)
      return;

  lastMeasurement = now_ms;
if (now_ms - lastMeasurement >= MEASUREMENT_INTERVAL) {
  uint32_t tMeter = micros();
 
    
    // Citire frecvență (cu calibrare)
uint16_t freq_raw = meter.getFreq() & 0x0FFF;   // FREQ e 12-bit
Frequency = (double)freq_raw / (double)FREQ_CAL;

   //Serial.printf("RAW=%u  CAL=%.2f  FREQ=%.2f\n", freq_raw, (double)FREQ_CAL, Frequency);
 
    // ───────────────────────────────────────────────────────────
    // CITIRI VRMS și IRMS CU CONSTANTE SEPARATE PER FAZĂ
    // ───────────────────────────────────────────────────────────
    
// Threshold-uri pentru eliminare zgomot
const float VOLTAGE_THRESHOLD = 10.0f;  // sub 10V afișează 0
const float CURRENT_THRESHOLD = 0.5f;   // sub 0.5A afișează 0

// CT ratio din WebUI (asigură-te că e float)
float CT_Ratio = (float)CT_Primary / (float)CT_Secondary;

// --- VRMS: scazi offsetul în COUNTS, apoi scalezi în Volți ---
float vA_counts = (float)meter.getVRMS(PHASE_A) - voltageOffsetA;
float vB_counts = (float)meter.getVRMS(PHASE_B) - voltageOffsetB;
float vC_counts = (float)meter.getVRMS(PHASE_C) - voltageOffsetC;



// Serial.printf("RAW IA=%ld  offI=%.0f  diffI=%.0f | RAW VA=%ld offV=%.0f diffV=%.0f\n",
//               rawIA, currentOffsetA, (float)rawIA - currentOffsetA,
//               rawVA, voltageOffsetA, (float)rawVA - voltageOffsetA);
//----------------

if (vA_counts < 0) vA_counts = 0;
if (vB_counts < 0) vB_counts = 0;
if (vC_counts < 0) vC_counts = 0;

float v_a_raw = vA_counts * VRMS_SCALE_A * voltageFactor;
float v_b_raw = vB_counts * VRMS_SCALE_B * voltageFactor;
float v_c_raw = vC_counts * VRMS_SCALE_C * voltageFactor;


float rawIA = (float)meter.getIRMS(PHASE_A);
float iA_counts = rawIA - currentOffsetA;   // offset primul
if (iA_counts < 0) iA_counts = 0;           // apoi clamp

float rawIB = (float)meter.getIRMS(PHASE_B);
float iB_counts = rawIB - currentOffsetB;   // offset primul
if (iB_counts < 0) iB_counts = 0;           // apoi clamp

float rawIC = (float)meter.getIRMS(PHASE_C);
float iC_counts = rawIC - currentOffsetC;   // offset primul
if (iC_counts < 0) iC_counts = 0;           // apoi clamp


float c_a_raw = iA_counts * IRMS_SCALE_A * CT_Ratio * currentFactor;
float c_b_raw = iB_counts * IRMS_SCALE_B * CT_Ratio * currentFactor;
float c_c_raw = iC_counts * IRMS_SCALE_C * CT_Ratio * currentFactor;

// Aplicare threshold (elimină zgomotul sub valorile minime)
v_a = (v_a_raw > VOLTAGE_THRESHOLD) ? v_a_raw : 0.0f;
v_b = (v_b_raw > VOLTAGE_THRESHOLD) ? v_b_raw : 0.0f;
v_c = (v_c_raw > VOLTAGE_THRESHOLD) ? v_c_raw : 0.0f;

c_a = (c_a_raw > CURRENT_THRESHOLD) ? c_a_raw : 0.0f;
c_b = (c_b_raw > CURRENT_THRESHOLD) ? c_b_raw : 0.0f;
c_c = (c_c_raw > CURRENT_THRESHOLD) ? c_c_raw : 0.0f;

    // ───────────────────────────────────────────────────────────
    // CALCUL PUTERI ȘI FACTOR DE PUTERE
    // ───────────────────────────────────────────────────────────
    
    // 🔹 Puteri brute din ADE (doar pentru cosφ)
    float Watt_a_raw = meter.getWatt(PHASE_A);
    float Watt_b_raw = meter.getWatt(PHASE_B);
    float Watt_c_raw = meter.getWatt(PHASE_C);

    float VA_a_raw = meter.getVa(PHASE_A);
    float VA_b_raw = meter.getVa(PHASE_B);
    float VA_c_raw = meter.getVa(PHASE_C);

// 🔹 Factori de putere CORECȚI: PF = ΔWATTHR / ΔVAHR (aceeași fereastră) + FILTRARE (EMA)

// --- stare "previous" + filtrare (rămân static în loop, nu global) ---
static bool pfInit = false;
static uint32_t prevWhr[3]  = {0, 0, 0};
static uint32_t prevVahr[3] = {0, 0, 0};

static float pfFilteredA = 1.0f;
static float pfFilteredB = 1.0f;
static float pfFilteredC = 1.0f;

const float PF_FILTER_ALPHA = 0.3f;  // 0.1=smooth, 0.3=rapid
const int32_t PF_MIN_DVA = 200;      // prag minim pe delta VA (counts) ca să evit jitter/div0

// --- citim acumulatoarele 24-bit (NU valorile scalate în kW/kVA) ---
uint32_t whrA  = ((uint32_t)meter.getWatt(PHASE_A)) & 0xFFFFFF;
uint32_t whrB  = ((uint32_t)meter.getWatt(PHASE_B)) & 0xFFFFFF;
uint32_t whrC  = ((uint32_t)meter.getWatt(PHASE_C)) & 0xFFFFFF;

uint32_t vahrA = ((uint32_t)meter.getVa(PHASE_A)) & 0xFFFFFF;
uint32_t vahrB = ((uint32_t)meter.getVa(PHASE_B)) & 0xFFFFFF;
uint32_t vahrC = ((uint32_t)meter.getVa(PHASE_C)) & 0xFFFFFF;

if (!pfInit) {
  // prima rulare: doar inițializăm "previous"
  prevWhr[0]  = whrA;  prevWhr[1]  = whrB;  prevWhr[2]  = whrC;
  prevVahr[0] = vahrA; prevVahr[1] = vahrB; prevVahr[2] = vahrC;
  pfInit = true;

  // păstrăm ce aveai (1.0 filtrat)
  PfA = pfFilteredA;
  PfB = pfFilteredB;
  PfC = pfFilteredC;
} else {
  // delte (energia în fereastra dintre două citiri)
  int32_t dW_A  = deltaSigned24(whrA,  prevWhr[0]);
  int32_t dW_B  = deltaSigned24(whrB,  prevWhr[1]);
  int32_t dW_C  = deltaSigned24(whrC,  prevWhr[2]);

  int32_t dVA_A = deltaSigned24(vahrA, prevVahr[0]);
  int32_t dVA_B = deltaSigned24(vahrB, prevVahr[1]);
  int32_t dVA_C = deltaSigned24(vahrC, prevVahr[2]);

  // update "previous"
  prevWhr[0]  = whrA;  prevWhr[1]  = whrB;  prevWhr[2]  = whrC;
  prevVahr[0] = vahrA; prevVahr[1] = vahrB; prevVahr[2] = vahrC;

  auto updatePf = [&](int32_t dW, int32_t dVA, float &pfFilt, float &pfOut) {
    if (abs(dVA) < PF_MIN_DVA) {   // prea mic -> nu update
      pfOut = pfFilt;
      return;
    }
    float pfInstant = (float)dW / (float)dVA;
    pfInstant = constrain(pfInstant, -1.0f, 1.0f);
    pfFilt = PF_FILTER_ALPHA * pfInstant + (1.0f - PF_FILTER_ALPHA) * pfFilt;
    pfOut  = pfFilt;
  };

  updatePf(dW_A, dVA_A, pfFilteredA, PfA);
  updatePf(dW_B, dVA_B, pfFilteredB, PfB);
  updatePf(dW_C, dVA_C, pfFilteredC, PfC);
}


    // 🔹 Puteri active (P = Ufn * I * cosφ) => rezultatul în kW
    WattA = (v_a * c_a * PfA) / 1000.0f;
    WattB = (v_b * c_b * PfB) / 1000.0f;
    WattC = (v_c * c_c * PfC) / 1000.0f;
    Watt  = WattA + WattB + WattC;

    // 🔹 Puteri aparente (S = Ufn * I) în kVA
    VA_a = (v_a * c_a) / 1000.0f;
    VA_b = (v_b * c_b) / 1000.0f;
    VA_c = (v_c * c_c) / 1000.0f;
    VA   = VA_a + VA_b + VA_c;

    // 🔹 Puteri reactive (Q = sqrt(S² - P²)) în kVAr
    Var_a = sqrtf(fmaxf(0.0f, VA_a*VA_a - WattA*WattA));
    Var_b = sqrtf(fmaxf(0.0f, VA_b*VA_b - WattB*WattB));
    Var_c = sqrtf(fmaxf(0.0f, VA_c*VA_c - WattC*WattC));
    Var   = Var_a + Var_b + Var_c;

    // 🔹 Factor de putere total
    if (VA > 0.1f) Pf = Watt / VA; else Pf = 1.0f;

   profUpdate(prof.maxMeterUs, micros() - tMeter);
    lastMeasurement = now_ms;
  }
   }
void TaskMeter(void *pv) {
  for(;;) {
    doMeasurements();
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}


// ═══════════════════════════════════════════════════════════════
// FUNCȚIA SETUP() COMPLETĂ - ÎNLOCUIEȘTE ÎN MAIN.INO
// ═══════════════════════════════════════════════════════════════

void setup() {
  // ═══════════════════════════════════════════════════════════
  // 🔧 INIȚIALIZARE GPIO (PRIMA ACȚIUNE ABSOLUTĂ!)
  // ═══════════════════════════════════════════════════════════
    Serial.begin(115200);
  delay(1000);
  Serial.println("BOOT: entered setup()");
  safeGPIOInit();
  delay(10);
  
  // 🔹 Inițializare pin pentru control alimentare stepuri (mosfet P)
  pinMode(STEPS_POWER_EN_PIN, OUTPUT);
  digitalWrite(STEPS_POWER_EN_PIN, stepsEnabled ? LOW : HIGH);  // LOW = ON, HIGH = OFF
  Serial.printf("🔌 Pin alimentare stepuri (GPIO %d): %s\n", 
                STEPS_POWER_EN_PIN, stepsEnabled ? "ON" : "OFF");
  
  // ═══════════════════════════════════════════════════════════
  // ⚡ CONFIGURARE PWM
  // ═══════════════════════════════════════════════════════════
  ledcSetup(PWM_CHANNEL, PWM_FREQ, PWM_RES);
  ledcWrite(PWM_CHANNEL, 0);
  ledcAttachPin(PWM_PIN, PWM_CHANNEL);
  ledcWrite(PWM_CHANNEL, 0);
  setPWM(0);

  // ═══════════════════════════════════════════════════════════
  // 📡 PORNIRE SERIAL
  // ═══════════════════════════════════════════════════════════
 // Serial.begin(115200);
  //delay(2000);  // Așteaptă stabilizarea Serial
  
  Serial.println("\n\n");
  Serial.println("╔═══════════════════════════════════════════════════════════╗");
  Serial.println("║                ESP32-S3 POWER MONITOR V07                 ║");
  Serial.println("║              OTA Rollback + Dual Network                  ║");
  Serial.println("╚═══════════════════════════════════════════════════════════╝");
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 🔍 VERIFICARE COMPLETĂ CONFIGURAȚIE OTA
  // ═══════════════════════════════════════════════════════════
  
  Serial.println("┌───────────────────────────────────────┐");
  Serial.println("│    OTA Configuration Check            │");
  Serial.println("└───────────────────────────────────────┘");
  
  // 1️⃣ Verifică dacă rollback este activat în build
  bool rollbackEnabled = false;
  #ifdef CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE
    Serial.println("✅ Rollback: ENABLED");
    rollbackEnabled = true;
  #else
    Serial.println("❌ Rollback: DISABLED");
    Serial.println();
    Serial.println("⚠️  ATENȚIE: Rollback-ul nu este activat!");
    Serial.println("📋 Soluție:");
    Serial.println("   1. Creează fișier 'sdkconfig' în folderul sketch-ului");
    Serial.println("   2. Adaugă: CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE=y");
    Serial.println("   3. Închide și redeschide Arduino IDE");
    Serial.println("   4. Recompilează firmware-ul");
    Serial.println();
  #endif
  
  // 2️⃣ Verifică existența partițiilor OTA
  const esp_partition_t* ota0 = esp_partition_find_first(
    ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_0, NULL);
  const esp_partition_t* ota1 = esp_partition_find_first(
    ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_1, NULL);
  const esp_partition_t* otadata = esp_partition_find_first(
    ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_OTA, NULL);
  
  bool partitionsOK = false;
  if (ota0 && ota1 && otadata) {
    Serial.println("✅ Partiții OTA: Configurate corect");
    Serial.printf("   • OTA_0: 0x%06X (%u KB)\n", ota0->address, ota0->size / 1024);
    Serial.printf("   • OTA_1: 0x%06X (%u KB)\n", ota1->address, ota1->size / 1024);
    partitionsOK = true;
  } else {
    Serial.println("❌ Partiții OTA: Incomplete!");
    if (!ota0) Serial.println("   ✗ Lipsește: OTA_0");
    if (!ota1) Serial.println("   ✗ Lipsește: OTA_1");
    if (!otadata) Serial.println("   ✗ Lipsește: OTADATA");
    Serial.println();
    Serial.println("📋 Soluție:");
    Serial.println("   Tools → Partition Scheme");
    Serial.println("   Alege: '16M Flash (3MB APP/9.9MB FATFS)'");
    Serial.println();
  }
  
  // 3️⃣ Afișează starea partițiilor curente
  const esp_partition_t* running = esp_ota_get_running_partition();
  const esp_partition_t* boot = esp_ota_get_boot_partition();
  
  if (running) {
    Serial.printf("Running partition: %s (0x%06X)\n", running->label, running->address);
  }
  if (boot) {
    Serial.printf("Boot partition:    %s (0x%06X)\n", boot->label, boot->address);
  }
  
  // 4️⃣ Verifică starea firmware-ului
  esp_ota_img_states_t state = ESP_OTA_IMG_UNDEFINED;
  esp_err_t err = esp_ota_get_state_partition(running, &state);
  
  if (err == ESP_OK) {
    Serial.print("Firmware State:    ");
    switch(state) {
      case ESP_OTA_IMG_NEW:
        Serial.println("NEW (prima pornire după OTA)");
        break;
      case ESP_OTA_IMG_PENDING_VERIFY:
        Serial.println("PENDING_VERIFY ⏳");
        Serial.println();
        Serial.println("⚠️  Firmware va fi confirmat după 15 secunde");
        Serial.println("    SAU va face rollback dacă crash-uiește!");
        Serial.println();
        break;
      case ESP_OTA_IMG_VALID:
        Serial.println("VALID ✅");
        break;
      case ESP_OTA_IMG_INVALID:
        Serial.println("INVALID ❌");
        break;
      case ESP_OTA_IMG_ABORTED:
        Serial.println("ABORTED");
        break;
      default:
        Serial.println("UNDEFINED");
        break;
    }
  } else {
    Serial.printf("⚠️  Nu pot determina starea: %s\n", esp_err_to_name(err));
  }
  
  // 5️⃣ Sumarul configurației OTA
  Serial.println();
  if (rollbackEnabled && partitionsOK) {
    Serial.println("🎉 OTA ROLLBACK: Complet configurat și funcțional!");
  } else {
    Serial.println("⚠️  OTA ROLLBACK: NU este complet configurat!");
    if (!rollbackEnabled) Serial.println("   → Lipsește configurarea rollback");
    if (!partitionsOK) Serial.println("   → Lipsesc partiții OTA");
  }
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 🔁 INFORMAȚII RESET
  // ═══════════════════════════════════════════════════════════
  auto rr = esp_reset_reason();
  Serial.printf("Reset reason: %s (%d)\n", resetReasonToStr(rr), rr);
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 🔒 INIȚIALIZARE MUTEX-URI
  // ═══════════════════════════════════════════════════════════
  if (i2cMutex == nullptr) {
    i2cMutex = xSemaphoreCreateMutex();
    Serial.println("✅ I2C Mutex creat");
  }
  if (spiMutex == nullptr) {
    spiMutex = xSemaphoreCreateMutex();
    Serial.println("✅ SPI Mutex creat");
  }
  if (g_modbusMutex == nullptr) {
    g_modbusMutex = xSemaphoreCreateMutex();
    Serial.println("✅ Modbus Mutex creat");
  }
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // ⚙️  SETĂRI SISTEM
  // ═══════════════════════════════════════════════════════════
  setCpuFrequencyMhz(240);
  Serial.printf("CPU Frequency: %d MHz\n", getCpuFrequencyMhz());
  
  preferences.begin("settings", false);
  Serial.println("✅ NVRAM (Preferences) inițializat");
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 👆 TOUCH SENSOR
  // ═══════════════════════════════════════════════════════════
  displayOn = true;
  lastTouchTime = millis();
  Serial.println("✅ Touch sensor (GPIO4) configurat");
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 🔄 RESET W5500 ETHERNET
  // ═══════════════════════════════════════════════════════════
  Serial.println("Resetare W5500...");
  resetW5500();
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 🔌 INIȚIALIZARE I2C (OLED + DAC + EEPROM)
  // ═══════════════════════════════════════════════════════════
  Wire.begin(48, 47);  // SDA=GPIO48, SCL=GPIO47
  Wire.setTimeout(50);
  Serial.println("✅ I2C Bus inițializat (GPIO48/47)");

  // ═══════════════════════════════════════════════════════════
  // 📊 DAC MCP4725 - Configurare Sigură
  // ═══════════════════════════════════════════════════════════
  Serial.println("Configurare DAC MCP4725...");
  dac.begin(0x60);
  
  bool dacEepromSet = preferences.getBool("dac_eeprom", false);
  
  if (!dacEepromSet) {
    Serial.println("  → Prima pornire - salvez 0V în EEPROM DAC");
    dac.setVoltage(0, true);  // Salvează în EEPROM
    delay(50);
    preferences.putBool("dac_eeprom", true);
    Serial.println("  → ✅ EEPROM DAC configurat (0V la pornire)");
  } else {
    dac.setVoltage(0, false);  // Doar setează la 0V
    Serial.println("  → DAC setat la 0V (EEPROM deja configurat)");
  }
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 🖥️  DISPLAY OLED SSD1306
  // ═══════════════════════════════════════════════════════════
  Serial.println("Inițializare OLED Display...");
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("❌ OLED nu a fost detectat!");
  } else {
    display.clearDisplay();
    display.setTextSize(2);
    display.setTextColor(WHITE);
    display.setCursor(32, 0);
    display.println("EBS");
    display.setTextSize(1);
    display.setCursor(2, 28);
    display.print("Booting V7.0...");
    display.display();
    Serial.println("✅ OLED Display activ");
  }
  Serial.println();

// ═══════════════════════════════════════════════════════════
  // ⚡ ADE7758 ENERGY METER - CONFIGURARE DEFINITIVĂ
  // ═══════════════════════════════════════════════════════════
  Serial.println("⚡ Configurare ADE7758 Energy Meter...\n");
  
  // Inițializare SPI hardware
  SPI.begin(8, 6, 7, 5);
 Serial.println("\n🔍 Test hardware MISO:");
pinMode(6, INPUT);
Serial.printf("MISO (GPIO6) idle = %d\n", digitalRead(6));
delay(100);
  SPI.setFrequency(SPI_FREQ);
  
  // NU apela Init() - configurăm totul manual!
  pinMode(5, OUTPUT);
  digitalWrite(5, HIGH);
  delay(100);

  // ───────────────────────────────────────────────────────────
  // PASUL 1: SOFTWARE RESET COMPLET
  // ───────────────────────────────────────────────────────────
  Serial.println("1️⃣ Software reset complet...");
  meter.write8bits(OPMODE, SWRST);  // Scrie direct, fără setOpMode()
  delay(50);  // Așteaptă reset complet


  // ───────────────────────────────────────────────────────────
  // PASUL 2: CONFIGURARE OPMODE (FORȚAT!)
  // ───────────────────────────────────────────────────────────
  Serial.println("2️⃣ Configurare OPMODE (HPF enabled)...");
  
  // Scrie OPMODE = 0x04 (doar DISCF, HPF enabled)
  meter.write8bits(OPMODE, DISCF);
  delay(20);
  
  // VERIFICĂ și rescrie dacă e necesar
  uint8_t opmode_check = meter.read8bits(OPMODE);
  if (opmode_check != DISCF) {
    Serial.printf("  ⚠️  OPMODE greșit (0x%02X), rescriu...\n", opmode_check);
    meter.write8bits(OPMODE, DISCF);
    delay(20);
    opmode_check = meter.read8bits(OPMODE);
    Serial.printf("  → OPMODE acum: 0x%02X\n", opmode_check);
  }
  
  // ───────────────────────────────────────────────────────────
  // PASUL 3: CONFIGURARE REGISTRE DE BAZĂ
  // ───────────────────────────────────────────────────────────
  Serial.println("3️⃣ Configurare registre de bază...");
  
  meter.write8bits(MMODE, 0x00);
  delay(10);
  
  meter.write8bits(WAVMODE, 0x00);
  delay(10);
  
  meter.write8bits(LCYCMODE, 0x78);
  delay(10);
  
  meter.write16bits(LINECYC, 30);
  delay(10);
  
  // ───────────────────────────────────────────────────────────
  // PASUL 4: CONFIGURARE GAIN (FORȚAT!)
  // ───────────────────────────────────────────────────────────
  Serial.println("4️⃣ Configurare GAIN registers...");
  
  // GAIN principal = 0x00 (unity gain)
  meter.write8bits(GAIN, 0x00);
  delay(20);
  
  // Verifică și rescrie dacă necesar
  uint8_t gain_check = meter.read8bits(GAIN);
  if (gain_check != 0x00) {
    Serial.printf("  ⚠️  GAIN greșit (0x%02X), rescriu...\n", gain_check);
    meter.write8bits(GAIN, 0x00);
    delay(20);
  }
  
  // GAIN registers per fază
  meter.write16bits(0x24, 0x0000);  // AVRMSGAIN
  meter.write16bits(0x25, 0x0000);  // BVRMSGAIN
  meter.write16bits(0x26, 0x0000);  // CVRMSGAIN
  meter.write16bits(0x27, 0x0000);  // AIGAIN
  meter.write16bits(0x28, 0x0000);  // BIGAIN
  meter.write16bits(0x29, 0x0000);  // CIGAIN
  delay(10);
  
  // ───────────────────────────────────────────────────────────
  // PASUL 5: CONFIGURARE DIVIZORI (FORȚAT!)
  // ───────────────────────────────────────────────────────────
  Serial.println("5️⃣ Configurare divizori...");
  
  meter.write8bits(WDIV, 0x02);
  meter.write8bits(VARDIV, 0x02);
  meter.write8bits(VADIV, 0x02);
  delay(20);
  
  // Verifică și rescrie dacă necesar
  uint8_t wdiv_check = meter.read8bits(WDIV);
  if (wdiv_check != 0x02) {
    Serial.printf("  ⚠️  WDIV greșit (0x%02X), rescriu...\n", wdiv_check);
    meter.write8bits(WDIV, 0x02);
    meter.write8bits(VARDIV, 0x02);
    meter.write8bits(VADIV, 0x02);
    delay(20);
  }
  
  // ───────────────────────────────────────────────────────────
  // PASUL 6: RESETARE OFFSET REGISTERS
  // ───────────────────────────────────────────────────────────
  Serial.println("6️⃣ Resetare offset registers...");
  
  meter.write16bits(0x33, 0);  // AVRMSOS
  meter.write16bits(0x34, 0);  // BVRMSOS
  meter.write16bits(0x35, 0);  // CVRMSOS
  meter.write16bits(0x36, 0);  // AIRMSOS
  meter.write16bits(0x37, 0);  // BIRMSOS
  meter.write16bits(0x38, 0);  // CIRMSOS
  delay(10);
  
  meter.resetStatus();
  delay(50);
  
  // ───────────────────────────────────────────────────────────
  // PASUL 7: VERIFICARE FINALĂ REGISTRE
  // ───────────────────────────────────────────────────────────
  Serial.println("7️⃣ Verificare configurație finală...\n");
  delay(200);  // Așteaptă stabilizare completă
  
  uint8_t opmode_final = meter.read8bits(OPMODE);
  uint8_t mmode_final = meter.read8bits(MMODE);
  uint8_t gain_final = meter.read8bits(GAIN);
  uint8_t wdiv_final = meter.read8bits(WDIV);
  uint8_t vardiv_final = meter.read8bits(VARDIV);
  uint8_t vadiv_final = meter.read8bits(VADIV);
  
  Serial.println("────── Registre finale ──────");
  Serial.printf("  OPMODE: 0x%02X (HPF=%s, CF=%s)\n", 
                opmode_final,
                (opmode_final & DISHPF) ? "OFF" : "ON",
                (opmode_final & DISCF) ? "OFF" : "ON");
  Serial.printf("  MMODE:  0x%02X\n", mmode_final);
  Serial.printf("  GAIN:   0x%02X\n", gain_final);
  Serial.printf("  WDIV:   0x%02X\n", wdiv_final);
  Serial.printf("  VARDIV: 0x%02X\n", vardiv_final);
  Serial.printf("  VADIV:  0x%02X\n", vadiv_final);
  
  // ULTIMĂ VERIFICARE - dacă OPMODE încă greșit, RESCRIE!
  if (opmode_final != DISCF) {
    Serial.println("\n⚠️  OPMODE încă greșit! Ultim attempt...");
    meter.write8bits(OPMODE, DISCF);
    delay(50);
    opmode_final = meter.read8bits(OPMODE);
    Serial.printf("  → OPMODE final: 0x%02X\n", opmode_final);
  }
  
  Serial.println("─────────────────────────────\n");
  
  // ───────────────────────────────────────────────────────────
  // PASUL 8: TEST SPI
  // ───────────────────────────────────────────────────────────
  Serial.println("8️⃣ Test comunicare SPI...");
  
  meter.write16bits(LINECYC, 0x1234);
  delay(10);
  uint16_t test_val = meter.read16bits(LINECYC);
  
  if (test_val == 0x1234) {
    Serial.println("  ✅ SPI OK");
  } else {
    Serial.printf("  ⚠️  SPI WARNING - citit=0x%04X\n", test_val);
  }
  
  meter.write16bits(LINECYC, 30);
  delay(10);
  
  // ───────────────────────────────────────────────────────────
  // PASUL 9: CITIRE RAW
  // ───────────────────────────────────────────────────────────
  Serial.println("\n9️⃣ Citire valori RAW...");
  delay(500);  // Așteaptă stabilizare ADC cu HPF
  
  long raw_vrms_a = meter.read24bits(AVRMS);
  long raw_vrms_b = meter.read24bits(BVRMS);
  long raw_vrms_c = meter.read24bits(CVRMS);
  long raw_irms_a = meter.read24bits(AIRMS);
  long raw_irms_b = meter.read24bits(BIRMS);
  long raw_irms_c = meter.read24bits(CIRMS);
  uint16_t freq_raw = meter.read16bits(FREQ);
  
  Serial.println("\n────── Valori RAW ──────");
  Serial.printf("  VRMS: A=%ld  B=%ld  C=%ld\n", raw_vrms_a, raw_vrms_b, raw_vrms_c);
  Serial.printf("  IRMS: A=%ld  B=%ld  C=%ld\n", raw_irms_a, raw_irms_b, raw_irms_c);
  Serial.printf("  FREQ: %u (%.2f Hz)\n", freq_raw, freq_raw / FREQ_CAL);
  Serial.println("────────────────────────\n");
  
  // ═══════════════════════════════════════════════════════════
  // 💾 ÎNCĂRCARE SETĂRI DIN NVRAM
  // ═══════════════════════════════════════════════════════════
  Serial.println("Încărcare setări din NVRAM...");
  loadSettingsFromNVRAM();
  
DBG_PRINTLN("\n🔍 TEST VRMS/IRMS get vs read24 (dupa NVRAM load)\n");



long vr_get = meter.getVRMS(PHASE_A);
long vr_raw = meter.read24bits(AVRMS);

long ir_get = meter.getIRMS(PHASE_A);
long ir_raw = meter.read24bits(AIRMS);


// PASUL 10: AUTO-CALIBRARE (DIAGNOSTIC) - NU atinge offseturile!
// ═══════════════════════════════════════════════════════════
Serial.println("🔟 Pasul 10: Diagnostic RAW + scale (fara offset overwrite)...");
delay(200);

// Dacă ai făcut deja calibrarea de fabrică, nu mai are voie să schimbe nimic.
if (factoryCalDone) {
  Serial.println("🔒 factoryCalDone=TRUE -> Pasul 10 ruleaza DOAR diagnostic (fara scriere in NVRAM).");
}

const int N_SAMPLES = 10;

long sum_vrms_a = 0, sum_vrms_b = 0, sum_vrms_c = 0;
long sum_irms_a = 0, sum_irms_b = 0, sum_irms_c = 0;

int valid = 0;

for (int i = 0; i < N_SAMPLES; i++) {

  long vrA = meter.read24bits(AVRMS);
  long vrB = meter.read24bits(BVRMS);
  long vrC = meter.read24bits(CVRMS);

  long irA = meter.read24bits(AIRMS);
  long irB = meter.read24bits(BIRMS);
  long irC = meter.read24bits(CIRMS);


  // filtre simple anti-citiri invalide (optional)
  // 0xFFFFFF e tipic pentru "no data / bus issue" la 24-bit
  if (vrA == 0xFFFFFF || vrB == 0xFFFFFF || vrC == 0xFFFFFF ||
      irA == 0xFFFFFF || irB == 0xFFFFFF || irC == 0xFFFFFF) {
    delay(50);
    continue;
  }

  sum_vrms_a += vrA;
  sum_vrms_b += vrB;
  sum_vrms_c += vrC;

  sum_irms_a += irA;
  sum_irms_b += irB;
  sum_irms_c += irC;

  valid++;
  delay(50);
}

if (valid == 0) {
  Serial.println("❌ Pasul 10: Niciun esantion valid! Verifica SPI/ADE.");
} else {
  float avg_vrms_a = (float)sum_vrms_a / (float)valid;
  float avg_vrms_b = (float)sum_vrms_b / (float)valid;
  float avg_vrms_c = (float)sum_vrms_c / (float)valid;

  float avg_irms_a = (float)sum_irms_a / (float)valid;
  float avg_irms_b = (float)sum_irms_b / (float)valid;
  float avg_irms_c = (float)sum_irms_c / (float)valid;

  // ✅ Scale-urile rămân cele stabilite de tine (bază) — nu “auto” după raw!
  // Dacă vrei să le ajustezi, fă asta într-o procedură de calibrare cu referință reală (V/I cunoscute).
  const float VRMS_SCALE_BASE = 0.0001259f; // pentru voltageFactor=1.0 (empiric)
  const float IRMS_SCALE_BASE = 0.000060571f; // pentru CT secundar 1A (empiric)

  // Dacă vrei să păstrezi scale separate per fază, le setezi aici:
  // (dar NU le salva în NVRAM dacă factoryCalDone==true, ca să nu schimbi fabrica)
  float vrms_scale_a = VRMS_SCALE_BASE;
  float vrms_scale_b = VRMS_SCALE_BASE;
  float vrms_scale_c = VRMS_SCALE_BASE;

  float irms_scale_a = IRMS_SCALE_BASE;
  float irms_scale_b = IRMS_SCALE_BASE;
  float irms_scale_c = IRMS_SCALE_BASE;

  // Aplică scale-urile în variabilele de lucru (RAM)
  VRMS_SCALE_A = vrms_scale_a;
  VRMS_SCALE_B = vrms_scale_b;
  VRMS_SCALE_C = vrms_scale_c;

  IRMS_SCALE_A = irms_scale_a;
  IRMS_SCALE_B = irms_scale_b;
  IRMS_SCALE_C = irms_scale_c;

  // ✅ Offseturile sunt COUNTS din factory calibration (nu le recalcula aici!)
  // Dacă nu ai factory offsets încă, doar afișează ce există.
  Serial.println("\n────── RAW medii (counts) ──────");
  Serial.printf("  VRMS raw: A=%.0f  B=%.0f  C=%.0f  (valid=%d)\n", avg_vrms_a, avg_vrms_b, avg_vrms_c, valid);
  Serial.printf("  IRMS raw: A=%.0f  B=%.0f  C=%.0f\n", avg_irms_a, avg_irms_b, avg_irms_c);

  Serial.println("\n────── Offset factory (counts) ──────");
  Serial.printf("  V_off: A=%.0f  B=%.0f  C=%.0f\n", voltageOffsetA, voltageOffsetB, voltageOffsetC);
  Serial.printf("  I_off: A=%.0f  B=%.0f  C=%.0f\n", currentOffsetA, currentOffsetB, currentOffsetC);

  // calculează diferența în counts (asta e ce trebuie să fie aproape de 0 la 0V/0A)
  float dvA = avg_vrms_a - voltageOffsetA;
  float dvB = avg_vrms_b - voltageOffsetB;
  float dvC = avg_vrms_c - voltageOffsetC;

  float diA = avg_irms_a - currentOffsetA;
  float diB = avg_irms_b - currentOffsetB;
  float diC = avg_irms_c - currentOffsetC;

  Serial.println("\n────── Diferenta (raw - offset) counts ──────");
  Serial.printf("  dV: A=%.0f  B=%.0f  C=%.0f\n", dvA, dvB, dvC);
  Serial.printf("  dI: A=%.0f  B=%.0f  C=%.0f\n", diA, diB, diC);

  // (opțional) conversie doar ca diagnostic, NU ca offset:
  float CT_Ratio = (float)CT_Primary / (float)CT_Secondary;

  float vA_diag = (dvA > 0 ? dvA : 0) * VRMS_SCALE_A * voltageFactor;
  float vB_diag = (dvB > 0 ? dvB : 0) * VRMS_SCALE_B * voltageFactor;
  float vC_diag = (dvC > 0 ? dvC : 0) * VRMS_SCALE_C * voltageFactor;

  float iA_diag = (diA > 0 ? diA : 0) * IRMS_SCALE_A * CT_Ratio * currentFactor;
  float iB_diag = (diB > 0 ? diB : 0) * IRMS_SCALE_B * CT_Ratio * currentFactor;
  float iC_diag = (diC > 0 ? diC : 0) * IRMS_SCALE_C * CT_Ratio * currentFactor;

  Serial.println("\n────── Diagnostic (NU salvat) ──────");
  Serial.printf("  Vdiag: A=%.2fV  B=%.2fV  C=%.2fV\n", vA_diag, vB_diag, vC_diag);
  Serial.printf("  Idiag: A=%.2fA  B=%.2fA  C=%.2fA\n", iA_diag, iB_diag, iC_diag);
  Serial.println("──────────────────────────────\n");

  // ❌ NU salva offseturi aici. Nici măcar dacă factoryCalDone==false.
  // Offseturile se salvează DOAR în calibrazioneAutomaticaOffset().
}

Serial.println("✅ Pasul 10 complet.\n");
Serial.println("═══════════════════════════════════════════════════════════\n");



DBG_PRINTf("VRMS get=%ld  read24=%ld\n", vr_get, vr_raw);
DBG_PRINTf("IRMS get=%ld  read24=%ld\n", ir_get, ir_raw);
DBG_PRINTLN("");


  Serial.println("\n📋 Setări încărcate:");
  Serial.printf("  • Voltage Factor: %.3f\n", voltageFactor);
  Serial.printf("  • Current Factor: %.3f\n", currentFactor);
  Serial.printf("  • Voltage Offsets: A=%.2f, B=%.2f, C=%.2f\n", 
                voltageOffsetA, voltageOffsetB, voltageOffsetC);
  Serial.printf("  • Current Offsets: A=%.3f, B=%.3f, C=%.3f\n", 
                currentOffsetA, currentOffsetB, currentOffsetC);
  Serial.println();
DBG_PRINTf("   Offset V_A/B/C (counts): %.0f / %.0f / %.0f\n", voltageOffsetA, voltageOffsetB, voltageOffsetC);
DBG_PRINTf("   Offset I_A/B/C (counts): %.0f / %.0f / %.0f\n", currentOffsetA, currentOffsetB, currentOffsetC);




  // ═══════════════════════════════════════════════════════════
  // 📡 PORNIRE WiFi ACCESS POINT (ÎNTOTDEAUNA ACTIV)
  // ═══════════════════════════════════════════════════════════
  Serial.println("┌───────────────────────────────────────┐");
  Serial.println("│    WiFi Access Point                  │");
  Serial.println("└───────────────────────────────────────┘");
  
  startWebServer();
  
  Serial.println("✅ WiFi AP activ");
  Serial.printf("   SSID: EBS-Orbital-Config\n");
  Serial.printf("   IP:   %s\n", WiFi.softAPIP().toString().c_str());
  Serial.printf("   Web:  http://%s\n", WiFi.softAPIP().toString().c_str());
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 🌐 INIȚIALIZARE ETHERNET (OPȚIONAL)
  // ═══════════════════════════════════════════════════════════
  Serial.println("┌───────────────────────────────────────┐");
  Serial.println("│    Ethernet W5500 (Optional)          │");
  Serial.println("└───────────────────────────────────────┘");
  
  if (!ETH.beginSPI(W5500_MISO, W5500_MOSI, W5500_SCLK, W5500_CS, W5500_RST, W5500_IRQ)) {
    Serial.println("⚠️  W5500 nu a fost detectat");
    Serial.println("   Continuare doar cu WiFi AP");
    ethernetConnected = false;
  } else {
    Serial.println("✅ W5500 detectat - așteptare IP DHCP...");
    
    int maxTries = 4;
    while (ETH.localIP() == IPAddress(0, 0, 0, 0) && maxTries > 0) {
      Serial.printf("   Încercare %d/4...\n", 5 - maxTries);
      delay(1000);
      maxTries--;
    }

    if (ETH.localIP() == IPAddress(0, 0, 0, 0)) {
      Serial.println("⚠️  Ethernet: Timeout alocare IP");
      Serial.println("   Verifică cablul Ethernet");
      ethernetConnected = false;
    } else {
      Serial.println("✅ Ethernet conectat");
      Serial.printf("   IP:  %s\n", ETH.localIP().toString().c_str());
      Serial.printf("   Web: http://%s\n", ETH.localIP().toString().c_str());
      ethernetConnected = true;

      // ═══════════════════════════════════════════════════════
      // 🔗 TESTARE CONEXIUNE MODBUS TCP
      // ═══════════════════════════════════════════════════════
      Serial.println();
      Serial.println("Testare conexiune Modbus TCP...");
      Serial.printf("  Target: %s:%d\n", MODBUS_SLAVE_IP.toString().c_str(), MODBUS_PORT);
      
      client.stop();
      delay(100);

      if (client.connect(MODBUS_SLAVE_IP, MODBUS_PORT)) {
        Serial.println("✅ Modbus conectat la pornire");
        modbusConnected = true;
        client.setTimeout(2000);
        g_lastModbusTxMs = millis();
      } else {
        Serial.println("⚠️  Modbus nu răspunde");
        Serial.println("   Va încerca reconectare automată");
        modbusConnected = false;
      }

      // Pornește task-ul Modbus doar dacă Ethernet e activ
      Serial.println();
      Serial.println("Pornire Modbus Task...");
      xTaskCreatePinnedToCore(ModbusTask, "ModbusTask", 4096, NULL, 1, NULL, 1);
      Serial.println("✅ Modbus Task activ (Core 1)");
    }
  }
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // 🚀 PORNIRE TASK-URI RTOS
  // ═══════════════════════════════════════════════════════════
  Serial.println("┌───────────────────────────────────────┐");
  Serial.println("│    RTOS Tasks                         │");
  Serial.println("└───────────────────────────────────────┘");
  
  xTaskCreatePinnedToCore(ModbusReconnectTask, "ModbusReconnect", 4096, NULL, 1, 
                          &TaskHandle_ModbusReconnect, 1);
  Serial.println("✅ Modbus Reconnect Task (Core 1)");
  
  xTaskCreatePinnedToCore(updatePWMFromWatt, "PWM_Control", 4096, NULL, 3, 
                          &TaskHandle_Core2, 1);
  Serial.println("✅ PWM Control Task (Core 1)");
  
  xTaskCreatePinnedToCore(OledTask, "OledTask", 4096, nullptr, 1, nullptr, 1);
  Serial.println("✅ OLED Display Task (Core 1)");
  Serial.println();

  // ═══════════════════════════════════════════════════════════
  // ✅ SETUP COMPLET - SUMARUL FINAL
  // ═══════════════════════════════════════════════════════════
  Serial.println("╔═══════════════════════════════════════════════════════════╗");
  Serial.println("║              ✅ SETUP COMPLET - SISTEM ACTIV              ║");
  Serial.println("╚═══════════════════════════════════════════════════════════╝");
  Serial.println();
  Serial.println("📊 Status:");
Serial.printf("   • Free Heap: %d bytes\n", ESP.getFreeHeap());
  Serial.printf("   • PSRAM:     %d bytes\n", ESP.getPsramSize());
  Serial.println();
  Serial.println("🌐 Conexiuni:");
  Serial.printf("   • WiFi AP:   %s (întotdeauna activ)\n", 
                WiFi.softAPIP().toString().c_str());
  if (ethernetConnected) {
    Serial.printf("   • Ethernet:  %s (activ)\n", ETH.localIP().toString().c_str());
    Serial.printf("   • Modbus:    %s\n", modbusConnected ? "Conectat" : "Deconectat");
  } else {
    Serial.println("   • Ethernet:  Inactiv");
  }
  Serial.println();
  Serial.println("🔧 Pentru comenzi debug, tastează în Serial Monitor:");
  Serial.println("   S - Status sistem");
  Serial.println("   M - Reconectare Modbus");
  Serial.println("   R - Reset W5500");
  Serial.println("   X - Restart ESP32");
  Serial.println();
  Serial.println("════════════════════════════════════════════════════════════");
  Serial.println();
  
  // Actualizează display-ul OLED
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    display.clearDisplay();
    display.setTextSize(2);
    display.setCursor(10, 10);
    display.println("READY!");
    display.setTextSize(1);
    display.setCursor(5, 35);
    display.printf("WiFi: %s", WiFi.softAPIP().toString().c_str());
    if (ethernetConnected) {
      display.setCursor(5, 50);
      display.printf("ETH:  %s", ETH.localIP().toString().c_str());
    }
    display.display();
    xSemaphoreGive(i2cMutex);
  }

xTaskCreatePinnedToCore(
    TaskMeter,
    "TaskMeter",
    8192,
    NULL,
    2,
    NULL,
    1
);

  delay(2000);  // Lasă mesajul READY vizibil
} // ⬅️ ACEASTA este singura acoladă de închidere a funcției setup()


//================== Loop ===================
void loop() {
  const uint32_t now_ms = millis();

  if (Serial.available()) {
  String cmd = Serial.readStringUntil('\n');
  cmd.trim();
  if (cmd == "cal") calibrazioneAutomaticaOffset();
}


  // ✅ CONFIRMARE FIRMWARE (TREBUIE SĂ FIE LA ÎNCEPUT, O SINGURĂ DATĂ)
  if (!fwConfirmed && millis() > 15000) {  // După 15 secunde de funcționare stabilă
    const esp_partition_t* run = esp_ota_get_running_partition();
    esp_ota_img_states_t st;

    if (esp_ota_get_state_partition(run, &st) == ESP_OK) {
      Serial.printf("🔍 RUN partition: %s, state=%s\n", 
                    run->label, otaStateName(st));

      if (st == ESP_OTA_IMG_PENDING_VERIFY) {
        esp_ota_mark_app_valid_cancel_rollback();
        Serial.println("✅ Firmware CONFIRMED - rollback cancelled!");
      } else {
        Serial.println("ℹ️ Firmware already validated, no action needed");
      }
    } else {
      Serial.println("⚠️ Could not get OTA partition state");
    }

    fwConfirmed = true;  // Marcăm că am verificat
  }

  g_loopCounter++;
  if (now_ms - g_lastLoopTime >= 5000) {
    DBG_PRINTf("💓 System active: %lu iterations (netBusy: %s)\n",
               g_loopCounter, g_netBusy ? "YES" : "NO");
    g_loopCounter = 0;
    g_lastLoopTime = now_ms;
  }

  if (Serial.available() > 0) {
    char c = Serial.read();
    if (c=='s' || c=='S') {
      DBG_PRINTLN("📊 System Status:");
      DBG_PRINTf("  Uptime: %lu min\n", millis() / 60000);
      DBG_PRINTf("  Free Heap: %d bytes\n", ESP.getFreeHeap());
      DBG_PRINTf("  WiFi AP: %s\n", WiFi.softAPIP().toString().c_str());
      DBG_PRINTf("  Ethernet: %s\n", ethernetConnected ? "OK" : "NO");
      DBG_PRINTf("  Modbus: %s\n", modbusConnected ? "OK" : "NO");
    }
    else if (c=='r' || c=='R') {
      DBG_PRINTLN("🔥 Manual hard reset W5500 requested");
      g_hardResetPending = true;
    }
    else if (c=='m' || c=='M') {
      DBG_PRINTLN("🔄 Manual reconnect - stop client");
      if (client.connected()) client.stop();
      modbusConnected = false;
    }
    else if (c=='x' || c=='X') {
      DBG_PRINTLN("🔄 System restart in 3 seconds...");
      delay(3000);
      ESP.restart();
    }
  }

  static uint32_t lastAnalogCheck   = 0;
  static uint32_t lastMeasurement   = 0;
  static uint32_t lastDisplayUpdate = 0;
  static uint32_t lastDebugPrint    = 0;
  static uint32_t lastEthPoll       = 0;

  const uint32_t MEASUREMENT_INTERVAL     = 100;
  const uint32_t DISPLAY_UPDATE_INTERVAL  = 200;
  const uint32_t ANALOG_CHECK_INTERVAL    = 5000;
  const uint32_t ETH_POLL_INTERVAL        = 1000;
  const uint32_t DEBUG_PRINT_INTERVAL     = 2000;

  if (now_ms - lastAnalogCheck >= ANALOG_CHECK_INTERVAL) {
    int raw = analogRead(analogPin);
    TensAlimentare = (raw * 3.3f) / 4095.0f;

    long sum = 0;
    for (int i = 0; i < numReadings; i++) {
      sum += analogRead(analogPinBat);
      delay(1);
    }
    float rawBat = sum / (float)numReadings;
    batteryVoltage = (rawBat * 3.3f / 4095.0f) * 2.0f;

    lastAnalogCheck = now_ms;
  }

  // ═══════════════════════════════════════════════════════════
  // ⚡ CITIRI ADE7758 - CU CONSTANTE SEPARATE PER FAZĂ
  // ═══════════════════════════════════════════════════════════


  // ═══════════════════════════════════════════════════════════
  // 📊 ACUMULARE ENERGIE
  // ═══════════════════════════════════════════════════════════
  if ((now_ms - previousMillis) >= 1000) {
    previousMillis = now_ms;
    if (Watt > 0.1f) KWh += (Watt * 1.0f) / 3600.0f;
  }

  // ═══════════════════════════════════════════════════════════
  // 🌐 CHECK ETHERNET LINK STATE — PHYSICAL TRUTH
  // ═══════════════════════════════════════════════════════════
  uint32_t tEth = micros();
  bool currentLinkUp = ETH.linkUp();
  bool currentHasIP = (ETH.localIP() != IPAddress(0,0,0,0));

  if (currentLinkUp && currentHasIP) {
    if (!ethernetConnected) {
      DBG_PRINT("📡 Ethernet LINK RESTORED: ");
      DBG_PRINTLN(ETH.localIP());
      ethernetConnected = true;
    }
  } else {
    if (ethernetConnected || modbusConnected) {
      DBG_PRINTLN("🚨 PHYSICAL CABLE CUT — killing Modbus state NOW");
      if (client.connected()) client.stop();
      ethernetConnected = false;
      modbusConnected = false;
    }
  }
  // profUpdate(prof.maxEthUs, micros() - tEth);
  // ═══════════════════════════════════════════════════════════
  // 🌐 WEB SERVER (WiFi AP întotdeauna activ)
  // ═══════════════════════════════════════════════════════════
  uint32_t t0 = micros();
  handleWebClient();
  profUpdate(prof.maxWebUs, micros() - t0);

  // ═══════════════════════════════════════════════════════════
  // 🐛 DEBUG PERIODIC
  // ═══════════════════════════════════════════════════════════
  if (now_ms - lastDebugPrint >= DEBUG_PRINT_INTERVAL) {
    DBG_PRINTLN("-----------------------------");
    DBG_PRINTf("ADE Status: %.2f Hz, %.2f kW, %.2f kWh, Pf=%.2f\n",
               Frequency, Watt, KWh, Pf);
    DBG_PRINTf("Voltages: A=%.1fV, B=%.1fV, C=%.1fV\n", v_a, v_b, v_c);
    DBG_PRINTf("Currents: A=%.2fA, B=%.2fA, C=%.2fA\n", c_a, c_b, c_c);
    DBG_PRINTf("Network Status: WiFi=%s, Ethernet=%s, Modbus=%s\n",
               WiFi.softAPIP().toString().c_str(),
               ethernetConnected ? "OK" : "NO",
               modbusConnected ? "OK" : "NO");
    DBG_PRINTLN("-----------------------------");
    lastDebugPrint = now_ms;
  }
if (now_ms - prof.lastPrintMs > 2000) {
  prof.lastPrintMs = now_ms;
  Serial.printf("PROF max(us): web=%u meter=%u\n",
                prof.maxWebUs,
                prof.maxMeterUs);

  prof.maxWebUs = 0;
  prof.maxMeterUs = 0;
}

  yield();
  vTaskDelay(1);
  
  // 🐛 DEBUG RAW VALUES (OPȚIONAL - comentează după testare)
  // uint32_t ra = meter.getVRMS(PHASE_A);
  // uint32_t ia = meter.getIRMS(PHASE_A);
  // Serial.printf("RAW VRMS_A=0x%06lX  IRMS_A=0x%06lX\n", ra, ia);
}


// Helper function to convert reset reason to string
const char* resetReasonToStr(esp_reset_reason_t reason) {
  switch (reason) {
    case ESP_RST_UNKNOWN:    return "Unknown";
    case ESP_RST_POWERON:    return "Power On";
    case ESP_RST_EXT:        return "External Reset";
    case ESP_RST_SW:         return "Software Reset";
    case ESP_RST_PANIC:      return "Panic";
    case ESP_RST_INT_WDT:    return "Interrupt Watchdog";
    case ESP_RST_TASK_WDT:   return "Task Watchdog";
    case ESP_RST_WDT:        return "Other Watchdog";
    case ESP_RST_DEEPSLEEP:  return "Deep Sleep";
    case ESP_RST_BROWNOUT:   return "Brownout";
    case ESP_RST_SDIO:       return "SDIO";
    default:                 return "Other";
  }
}
